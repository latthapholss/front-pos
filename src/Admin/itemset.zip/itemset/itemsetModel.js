const knex = require("../../config/database");

class itemsetModel {
  async getProductDetails(productId) {
    try {
        // Fetch data for the highest-priced lot
        const highestPricedLot = await knex('product_lot')
            .select('product_lot_cost', 'product_lot_price', 'product_lot_qty')
            .where({
                product_id: productId,
                is_active: 1
            })
            .orderBy('product_lot_price', 'desc')
            .first(); // Get only the first row (highest-priced lot)

        if (!highestPricedLot) {
            // No active lots found for the product
            return null;
        }

        // Calculate the sum of quantities for all active lots
        const totalQuantityResult = await knex('product_lot')
            .sum('product_lot_qty as totalQuantity')
            .where({
                product_id: productId,
                is_active: 1
            })
            .first();

        const totalQuantity = totalQuantityResult.totalQuantity || 0;

        // Fetch product details including product ID
        const productDetails = await knex('product')
            .select('product_id', 'product_name')
            .where('product_id', productId)
            .first();

        // Return product details including product ID, along with the total quantity of all active lots
        return {
            productId: productDetails.product_id,
            productName: productDetails.product_name,
            maxPricedLot: highestPricedLot,
            totalQuantity: totalQuantity
        };
    } catch (error) {
        console.error("Error fetching product details:", error);
        throw error; // Propagate the error to the caller
    }
}

async delete_itemset(itemsetId) {
  try {
    await knex('itemset')
      .where('itemset_id', itemsetId)
      .update('is_active', 0);

    return true; // Return true if the deletion is successful
  } catch (error) {
    console.error("Error deleting item set:", error);
    throw error;
  }
}
update_product_img({ product_id, product_image }) {
  return knex('product').update({ product_image }).where({ product_id })
}


  async getProductLotWithHighestPrice(productId) {
    try {
      const productLot = await knex("product_lot")
        .select("product_lot_id")
        .where("product_id", productId)
        .andWhere("is_active", 1)
        .orderBy("product_lot_price", "desc")
        .first();

      return productLot.product_lot_id;
    } catch (error) {
      console.error("Error fetching product lot with highest price:", error);
      throw error;
    }
  }

  async reduceProductLotQuantity(productLotId, quantity) {
    try {
      await knex("product_lot")
        .where("product_lot_id", productLotId)
        .andWhere("is_active", 1)
        .decrement("product_lot_qty", quantity);
    } catch (error) {
      console.error("Error reducing product lot quantity:", error);
      throw error;
    }
  }

  addItemset(newItemset) {
    return knex("itemset").insert(newItemset);
  }

  addProduct(newProduct) {
    return knex("product").insert(newProduct);
  }

  additemsetlot(newLotItemset) {
    return knex("product_lot").insert(newLotItemset);
  }
  
  get_itemset() {
    return knex("itemset").select().where("is_active", 1);
  }

  addProductItemset(productItemset) {
    return knex("product_itemset").insert(productItemset);
  }
}

module.exports = new itemsetModel();
