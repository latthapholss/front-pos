const is_prod = false

const version = '/api/v1'
export const WEBSITE = is_prod ? '' : 'http://localhost:3000';
export const ip = (is_prod ? '' : 'http://localhost:4000') + version;
export const path_images = (is_prod ? '' : 'http://localhost:4000') + "/product/"

export const getImagePath = (img_name) => {
    return path_images + img_name
}

export const post = (object, path, token) => new Promise((resolve, reject) => {
    fetch(ip + path, {
        method: 'POST',
        headers: {
            "Access-Control-Allow-Origin": "*",
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'authorization': token
        }, body: JSON.stringify(object)
    }).then(res => {
        setTimeout(() => null, 0);
        return res.json()
    }).then(json => {
        resolve(json);
    }).catch((err) => reject(err))
})

  

  
export const get = (path, token) => new Promise((resolve, reject) => {
    fetch(ip + path, {
        method: 'GET',
        headers: {
            "Access-Control-Allow-Origin": "*",
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'authorization': token
        },
    }).then(res => {
        setTimeout(() => null, 0);
        return res.json()
    }).then(json => {
        resolve(json);
    }).catch((err) => reject(err))
})

// ################################################## URL ##################################################
export const LOGIN = '/auth/login'
export const LOGIN_MEMBER = '/auth/login_member';
export const REGISTER_MEMBER = '/auth/register_member'
export const UNIT ='/struct/unit'
export const ADD_UNIT='/struct/add_unit'
export const PRODUCT_TYPE='/struct/product_type'
export const ADD_PRODUCT_TYPE='/struct/add_product_type'
export const ADD_PRODUCT='/product/add_product'
export const UPDATE_PRODUCT= '/product/update_product'
export const ACTIVE_PRODUCT = '/product/active_product'
export const PRODUCT ='/product'
export const FILTERPRODUCT='/product/filter-products'
export const DELETEUNIT='/struct/soft-delete-unit'
export const DELETEPROTYPE='/struct/soft-delete-product-type'
export const PROMOTION='/promotion'
export const PROMOTIONSTATUS='/promotion/update-promotion-status'
export const PROMOTION_ADD='/promotion/addpromotion'