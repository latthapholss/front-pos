import React, { useState, useEffect } from 'react';
import {
  Box,
  Button,
  Grid,
  IconButton,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Typography,
  Paper,
  Container,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Switch,
  FormControlLabel,
  InputLabel,
  InputAdornment
} from '@mui/material';
import { Add as AddIcon, Edit as EditIcon, Delete as DeleteIcon } from '@mui/icons-material';
import SidebarAdmin from '../Component/Sidebar-Employee';
import { PROMOTION, PROMOTIONSTATUS, PROMOTION_ADD, get, post, } from '../Static/api';

function Promotionadd() {
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const [loading, setLoading] = useState(true);
  const [openDialog, setOpenDialog] = useState(false);
  const [promotionData, setPromotionData] = useState({
    promotion_name: '',
    promotion_detail: '',
    discount: '',
    promotion_start: '',
    promotion_end: '',
    quota: '',
  });

  const [promotions, setPromotions] = useState([]);

  const handleOpenDialog = () => {
    setOpenDialog(true);
  };

  useEffect(() => {
    handleGetPromotion();
    startAutoUpdatePromotionStatus(); 
  }, []);
  
  const handleCloseDialog = () => {
    setOpenDialog(false);
    setPromotionData({
      promotion_name: '',
      promotion_detail: '',
      discount: '',
      promotion_start: '',
      promotion_end: '',
      quota: '',
    });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setPromotionData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleEditMember = (promo) => {
    // ดำเนินการแก้ไขข้อมูลสมาชิกตามต้องการ
    console.log('Editing member:', promo);
  };

  const handleDeleteMember = (promoID) => {
    // ดำเนินการลบข้อมูลสมาชิกตามต้องการ
    console.log('Deleting member with ID:', promoID);
  };

  const handleSavePromotion = async () => {
    try {
      if (!promotionData.promotion_name) {
        alert('กรุณากรอกชื่อโปรโมชั่น');
        return;
      }
  
      if (isNaN(promotionData.discount)) {
        alert('กรุณากรอกค่า Discount ให้เป็นตัวเลข');
        return;
      }
  
      if (!promotionData.promotion_start || !promotionData.promotion_end) {
        alert('กรุณากรอกข้อมูลเริ่มต้นและสิ้นสุดโปรโมชั่น');
        return;
      }
  
      if (isNaN(promotionData.quota)) {
        alert('กรุณากรอกค่า Quota ให้เป็นตัวเลข');
        return;
      }
  
      // ถ้าไม่กรอก promotion_detail ให้กำหนดค่าเป็น "ไม่มีรายละเอียดโปรโมชั่น"
      const detail = promotionData.promotion_detail || 'ไม่มีรายละเอียดโปรโมชั่น';
  
      const newData = {
        ...promotionData,
        promotion_detail: detail,
      };
  
      // ทำสิ่งที่คุณต้องการเมื่อข้อมูลถูกกรอกครบถ้วน
      const res = await post(newData, PROMOTION_ADD);
  
      if (res.success) {
        console.log('Promotion added successfully:', res.message);
        // หรือจะทำการรีเฟรชหน้าหรือดำเนินการอื่นตามต้องการ
  
        // อัพเดตรายการโปรโมชั่นด้วยการดึงข้อมูลใหม่
        handleGetPromotion();
        // ทำการอัปเดตสถานะโปรโมชั่นอัตโนมัติ
        startAutoUpdatePromotionStatus();
      } else {
        console.error('Error adding promotion:', res.message);
      }
  
      // Close the dialog
      handleCloseDialog();
  
      // Log the saved promotion data
      console.log('Saved promotion data:', newData);
    } catch (error) {
      console.error('Error adding promotion:', error);
      // สามารถเพิ่มการจัดการข้อผิดพลาดแบบอื่น ๆ ตามต้องการ
    }
  };
  



  const handleGetPromotion = async () => {
    try {
      // เรียก API เพื่อดึงข้อมูลโปรโมชั่น
      const res = await get(PROMOTION);

      if (res.success) {
        // กรองข้อมูลที่มี is_active เท่ากับ 1
        const activePromotions = res.result.filter(item => item.is_active === 1);

        // ประมวลผลข้อมูลที่ได้รับ
        const modifiedData = activePromotions.map((item) => ({
          id: item.promotion_id,
          startDate: item.promotion_start,
          endDate: item.promotion_end,
          promotionName: item.promotion_name,
          detail: item.promotion_detail,
          discount: item.promotion_discount,
          quota: item.quota,
          selected: false,
        }));

        setPromotions(modifiedData);
        setLoading(false);
      }
    } catch (error) {
      console.error('Error fetching promotions:', error);
      setLoading(false);
    }
  };


  const startAutoUpdatePromotionStatus = () => {
    const interval = 30000; // 30 วินาทีในมิลลิวินาที
    
    // เรียกใช้ฟังก์ชัน updatePromotionStatus เพื่ออัปเดตสถานะโปรโมชั่น
    const autoUpdatePromotionStatus = async () => {
      try {
        await get(PROMOTIONSTATUS); // เรียกใช้งาน updatePromotionStatus โดยใส่วงเล็บ ()
        console.log('Promotion statuses updated.');
      } catch (error) {
        console.error('Error updating promotion statuses:', error);
      }
    }
  
    // เรียกฟังก์ชัน autoUpdatePromotionStatus ครั้งแรกเพื่อเริ่มการอัปเดตสถานะโปรโมชั่นโดยอัตโนมัติ
    autoUpdatePromotionStatus();
  
    // สร้าง interval เพื่อเรียกฟังก์ชัน autoUpdatePromotionStatus ในระหว่างที่ระบบทำงาน
    setInterval(() => {
      autoUpdatePromotionStatus();
      console.log('Auto update triggered.');
    }, interval);
  };
  




  const currentItems = promotions.slice(indexOfFirstItem, indexOfLastItem);

  return (
    <div>
      <Box sx={{ display: 'flex' }}>
        <Box sx={{ width: '240px' }}>
          <SidebarAdmin />
        </Box>
        <Box component="main" flexGrow={1} p={3}>
          <Container maxWidth="xl">
            <Grid container justifyContent="space-between" alignItems="center" mb={4}>
              <Typography variant="h5">โปรโมชั่น</Typography>
              <Button
                variant="contained"
                color="primary"
                startIcon={<AddIcon />}
                onClick={handleOpenDialog}
              >
                เพิ่มโปรโมชั่น
              </Button>

            </Grid>


            <Paper elevation={3} sx={{ width: '100%', borderRadius: 5, overflow: 'hidden' }}>
              <Table sx={{ borderRadius: 5 }}>
                <TableHead>
                  <TableRow>
                    <TableCell>ลำดับชุดโปรโมชั่น</TableCell>
                    <TableCell>ชื่อชุดโปรโมชั่น</TableCell>
                    <TableCell>รายละเอียดสินค้า</TableCell>
                    <TableCell>ราคาโปรโมชั่น</TableCell>
                    <TableCell>วันที่เริ่มต้น</TableCell>
                    <TableCell>วันที่หมดอายุ</TableCell>
                    <TableCell>เวลาเริ่มต้น</TableCell>
                    <TableCell>เวลาหมดอายุ</TableCell>
                    <TableCell>สถานะการใช้งาน</TableCell>
                    <TableCell>จำนวนโปรโมชั่น (quota)</TableCell>
                    <TableCell>แก้ไข</TableCell>
                    <TableCell>ลบ</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {currentItems.map((promotionData, index) => (
                    <TableRow key={promotionData.id}>
                      <TableCell>{indexOfFirstItem + index + 1}</TableCell>
                      <TableCell>{promotionData.promotionName}</TableCell>
                      <TableCell>{promotionData.detail}</TableCell>
                      <TableCell>{promotionData.discount}</TableCell>
                      <TableCell>{new Date(promotionData.startDate).toLocaleDateString()}</TableCell>
                      <TableCell>{new Date(promotionData.endDate).toLocaleDateString()}</TableCell>
                      <TableCell>{new Date(promotionData.startDate).toLocaleTimeString('th-TH', { hour: 'numeric', minute: 'numeric' })}</TableCell>
                      <TableCell>{new Date(promotionData.endDate).toLocaleTimeString('th-TH', { hour: 'numeric', minute: 'numeric' })}</TableCell>

                      <TableCell>
                        <Switch
                          checked={promotionData.selected}
                          onChange={() => handleEditMember(promotionData)}
                        />
                      </TableCell>
                      <TableCell>{promotionData.quota}</TableCell>
                      <TableCell>
                        <IconButton onClick={() => handleEditMember(promotionData)}>
                          <EditIcon />
                        </IconButton>
                      </TableCell>
                      <TableCell>
                        <IconButton onClick={() => handleDeleteMember(promotionData.id)}>
                          <DeleteIcon />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Paper>


          </Container>
        </Box>
      </Box>
      <Dialog open={openDialog} onClose={handleCloseDialog}>
        <DialogTitle>เพิ่มโปรโมชั่น</DialogTitle>
        <DialogContent>
          <TextField
            label="ชื่อโปรโมชั่น"
            name="promotion_name"
            value={promotionData.promotion_name}
            onChange={handleInputChange}
            fullWidth
            margin="normal"
          />
          <TextField
            label="รายละเอียดโปรโมชั่น"
            name="promotion_detail"
            value={promotionData.promotion_detail}
            onChange={handleInputChange}
            fullWidth
            margin="normal"
          />
          <TextField
            label="Discount (%)"
            name="discount"
            value={promotionData.discount}
            onChange={handleInputChange}
            type="number"
            InputProps={{
              inputProps: { min: 0, max: 100 },
            }}
            fullWidth
            margin="normal"
          />
          <TextField
            name="promotion_start"
            value={promotionData.promotion_start}
            onChange={handleInputChange}
            type="datetime-local"
            fullWidth
            InputLabelProps={{
              shrink: true,
              style: { position: 'relative', top: -12 }, // ปรับตำแหน่ง label
            }}
            InputProps={{
              startAdornment: <InputAdornment position="start">วันที่เริ่มโปรโมชั่น</InputAdornment>,
            }}
            margin="normal"
          />
          <TextField
            name="promotion_end"
            value={promotionData.promotion_end}
            onChange={handleInputChange}
            type="datetime-local"
            fullWidth
            InputLabelProps={{
              shrink: true,
              style: { position: 'relative', top: -12 }, // ปรับตำแหน่ง label
            }}
            InputProps={{
              startAdornment: <InputAdornment position="start">วันสิ้นสุดโปรโมชั่น</InputAdornment>,
            }}
            margin="normal"
          />
          <TextField
            label="จำนวนโปรโมชั่น (quota)"
            name="quota"
            value={promotionData.quota}
            onChange={handleInputChange}
            type="number"
            InputProps={{
              inputProps: { min: 0 },
            }}
            fullWidth
            margin="normal"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog} color="primary">
            ยกเลิก
          </Button>
          <Button onClick={handleSavePromotion} color="primary">
            บันทึก
          </Button>
        </DialogActions>
      </Dialog>

    </div>
  );


}

export default Promotionadd;
