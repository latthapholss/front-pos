import React, { useState, useEffect } from 'react';
import {
  Box,
  Button,
  Grid,
  IconButton,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Typography,
  Paper,
  Container,
  TextField,
  MenuItem,
  Pagination,
  CircularProgress
} from '@mui/material';
import { Add as AddIcon, Edit as EditIcon, Delete as DeleteIcon } from '@mui/icons-material';
import SidebarAdmin from '../Component/Sidebar-Employee';
import Navbaradmin from './navbaradmin';
import ProductDialog from '../Admin/ProductDialog';
import ProductTypeDialog from '../Admin/ProductTypeDialog';
import { ADD_PRODUCT_TYPE, PRODUCT, PRODUCT_TYPE, get, post, FILTERPRODUCT, ACTIVE_PRODUCT, UPDATE_PRODUCT } from '../Static/api';
import axios from 'axios';
import EditProductDialog from './EditProductDialog';

const UNITS_API_ENDPOINT = 'https://your-api-url.com/units';

function AdminProduct() {
  const [loading, setLoading] = useState(true);
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [units, setUnits] = useState([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [openTypeDialog, setOpenTypeDialog] = useState(false);
  const [openUnitDialog, setOpenUnitDialog] = useState(false);
  const [filterCategory, setFilterCategory] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [statusFilter, setStatusFilter] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(8);
  const [filterType, setFilterType] = useState('');
  const [editedProduct, setEditedProduct] = useState(null);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [openProductDialog, setOpenProductDialog] = useState(false);
  const [openEditDialog, setOpenEditDialog] = useState(false);
  const [selectedImageProp, setSelectedImageProp] = useState(null);




  const [updatedProduct, setUpdatedProduct] = useState({

    category: '',

  });
  const handleChange = (event) => {
    const { name, value } = event.target;
    setUpdatedProduct((prevProduct) => ({
      ...prevProduct,
      [name]: value,
    }));
  };
  console.log("updatedProduct:", updatedProduct);



  const [filterProductType, setFilterProductType] = useState('');












  const filterProductsByStatus = () => {
    if (statusFilter === '') {
      return filteredProducts; // ไม่กรองเลย
    }

    if (statusFilter === 'delete') {
      return filteredProducts.filter(product => product.is_active === false); // กรองสินค้าที่ถูกลบ
    }

    if (statusFilter === 'almost') {
      return filteredProducts.filter(product => product.quantity > 0 && product.quantity <= 20); // กรองสินค้าใกล้หมด
    }

    if (statusFilter === 'oos') {
      return filteredProducts.filter(product => product.quantity === 0); // กรองสินค้าหมด
    }

    return filteredProducts;
  };




























  useEffect(() => {
    handleGetCategories();
    handleGetUnits();
    handleGetProduct();

  }, []);


  const handleAddProduct = () => {
    setOpenProductDialog(true); // เปิด ProductDialog สำหรับการเพิ่มสินค้า
  };
  //บันทึกสินค้า
  const handleSaveProduct = async (newProduct) => {
    try {
      // เพิ่มสินค้าใหม่ลงในรายการสินค้าทั้งหมด
      setProducts((prevProducts) => [...prevProducts, newProduct]);

      // ปิดหน้าต่างสำหรับการเพิ่มสินค้า
      setOpenProductDialog(false);

      // รีเซ็ตคำค้นหาใหม่เป็นค่าว่าง
      setSearchQuery('');

      // ดึงข้อมูลสินค้าใหม่เพื่ออัปเดตรายการสินค้า
      handleGetProduct();


    } catch (error) {
      console.error('Error saving product:', error);
    }
  };






  //ลบสินค้าแบบsoftdelete
  const handleDeleteProduct = async (id) => {
    try {
      // เปลี่ยนสถานะ is_active เป็น false เมื่อกดปุ่มลบ (Soft Delete)
      await post({ product_id: id, is_active: false }, ACTIVE_PRODUCT);

      // อัปเดตรายการสินค้าใน state หลังจากลบสินค้าแล้ว (Soft Delete)
      setProducts((prevProducts) =>
        prevProducts.map((product) => (product.id === id ? { ...product, is_active: false } : product))
      );

      // อัปเดตรายการสินค้าใน filteredProducts หลังจากลบสินค้าแล้ว (Soft Delete)
      setFilteredProducts((prevProducts) =>
        prevProducts.map((product) => (product.id === id ? { ...product, is_active: false } : product))
      );

      console.log('สินค้าได้ถูกลบแล้ว', id); // แสดงข้อมูลใน Console เมื่อกดปุ่มลบสินค้าสำเร็จ

      handleGetProduct();
    } catch (error) {
      console.log(error);
      // การจัดการข้อผิดพลาด
    }

  };

  const getCurrentPageItems = () => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    return filteredProducts.slice(startIndex, endIndex);
  };
  /* ----------------------------- */
  const handleProductChange = (field, value) => {
    setEditedProduct((prevProduct) => ({
      ...prevProduct,
      [field]: value,
    }));
  };

  const handleEditProduct = (product) => {
    setSelectedProduct(product);
    setOpenEditDialog(true); // เปิด EditProductDialog
  };

  const handleUpdateProduct = async () => {
    try {
      // ส่งข้อมูลสินค้าที่อัปเดตไปยังเซิร์ฟเวอร์โดยใช้ฟังก์ชัน 'post'
      const res = await post(editedProduct, UPDATE_PRODUCT);

      if (res.success) {
        console.log('อัปเดตสินค้าเรียบร้อยแล้ว:', editedProduct.id);
        // อัปเดตสถานะและตัวอย่างผู้ใช้ตามความเหมาะสมเมื่อมีการอัปเดตสินค้าเสร็จสิ้น
        setProducts((prevProducts) =>
          prevProducts.map((product) => (product.id === editedProduct.id ? editedProduct : product))
        );
        setFilteredProducts((prevProducts) =>
          prevProducts.map((product) => (product.id === editedProduct.id ? editedProduct : product))
        );
        handleCloseDialog();
      } else {
        console.error('เกิดข้อผิดพลาดในการอัปเดตสินค้า:', res.message);
      }
    } catch (error) {
      console.error('เกิดข้อผิดพลาดในการอัปเดตสินค้า:', error);
    }
  };




  //กรองประเภทสินค้ายังใช้งานไม่ได้

  const handleCloseDialog = () => {
    setSelectedProduct(null);
    setOpenProductDialog(false); // Close ProductDialog
    setOpenEditDialog(false); // Close EditProductDialog
  };




  //ค้นหาตามตัวแรก
  const handleSearch = (event) => {
    const searchValue = event.target.value;
    const filteredProducts = products.filter((product) => {
      return (
        product.name.toLowerCase().includes(searchValue.toLowerCase()) ||
        product.description.toLowerCase().includes(searchValue.toLowerCase())
      );
    });
    setFilteredProducts(filteredProducts);
    setSearchQuery(searchValue);
  };

  //กรองสถานะใช้งานไม่ได้


  const handleFilterCategory = (event) => {
    const selectedCategoryId = event.target.value;
    console.log(selectedCategoryId);
    setFilterCategory(selectedCategoryId);
    setCurrentPage(1);

    if (selectedCategoryId === "") {
      setFilteredProducts(products);
    } else {
      const filteredByCategory = products.filter(product => product.category === selectedCategoryId);
      console.log(filteredByCategory);
      setFilteredProducts(filteredByCategory); // อัปเดตรายการสินค้าที่แสดงผล

    }
  };





  //get data สินค้า
  const handleGetProduct = async (status = '', category = '') => {
    try {
      const res = await get(PRODUCT, { status, category });
      if (res.success) {
        const data = res.result;
        const modifiedData = data.map((item) => ({
          id: item.product_id,
          name: item.product_name,
          costPrice: item.product_cost,
          sellingPrice: item.product_price,
          quantity: item.product_qty,
          description: item.product_detail,
          category: item.product_type,
          image: `http://localhost:4000/${item.product_image}`
        }));
        setProducts(modifiedData);
        setFilteredProducts(modifiedData);
      }
      setLoading(false);
    } catch (error) {
      console.error('Error fetching products:', error);
      setLoading(false);
    }
  };
  useEffect(() => {
    handleGetCategories();
    handleGetUnits();
  }, []);
  const handleGetCategories = async () => {
    try {
      const res = await get(PRODUCT_TYPE);
      if (res.success) {
        console.log('Categories response:', res.result);
        setCategories(res.result);
      }
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };



  const handleGetUnits = async () => {
    try {
      const res = await get(UNITS_API_ENDPOINT); // Fetch units using the appropriate API endpoint
      if (res.success) {
        setUnits(res.result);
      }
    } catch (error) {
      console.error('Error fetching units:', error);
    }
  };





  return (
    <Box sx={{ display: 'flex' }}>
      <Box sx={{ width: '240px' }}>
        <SidebarAdmin />
      </Box>
      <Box component="main" flexGrow={1} p={3}>
        <Container maxWidth="xl">
          <Grid container justifyContent="space-between" alignItems="center" mb={4}>
            <Typography variant="h5" sx={{ color: '#696CFF' }}>
              สินค้า
            </Typography>
            <Button
              variant="contained"
              color="primary"
              startIcon={<AddIcon />}
              onClick={handleAddProduct}
            >
              เพิ่มสินค้า
            </Button>
          </Grid>

          <Grid container spacing={2} mb={4}>
            <Grid item xs={12} sm={6} md={4}>

              <TextField
                select
                value={filterCategory}
                onChange={handleFilterCategory}
                label="กรองตามประเภทสินค้า"
                fullWidth
              >
                <MenuItem value="">ทั้งหมด</MenuItem>
                {categories.map((category) => (
                  <MenuItem key={category.product_type} value={category.product_type}>
                    {category.product_type}
                  </MenuItem>
                ))}
              </TextField>

            </Grid>

            <Grid item xs={12} sm={6} md={4}>
              <TextField
                value={searchQuery}
                onChange={handleSearch}
                label="ค้นหาสินค้า"
                fullWidth
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <TextField
                select
                value={filterType}
                onChange={(event) => {
                  setFilterType(event.target.value);
                  setStatusFilter(event.target.value); // อัปเดตค่าสถานะสำหรับการกรองสินค้า
                }}
                label="กรองสถานะสินค้า"
                fullWidth

              >
                <MenuItem value="">All</MenuItem>
                <MenuItem value="delete">สินค้าที่ลบ</MenuItem>
                <MenuItem value="almost">ใกล้หมด</MenuItem>
                <MenuItem value="oos">หมด</MenuItem>
              </TextField>
            </Grid>

            {/* Add the rest of your components here */}
          </Grid>

          <Paper elevation={3} sx={{ width: '100%', borderRadius: 5, overflow: 'hidden', marginBottom: 4 }}>
            {loading ? (
              <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: 200 }}>
                <CircularProgress />
              </Box>
            ) : (
              <Table sx={{ borderRadius: 5 }}>
                <TableHead>
                  <TableRow>
                    <TableCell>NO.</TableCell>
                    <TableCell>รหัสสินค้า</TableCell>
                    <TableCell>ชื่อสินค้า</TableCell>
                    <TableCell>ราคาทุน</TableCell>
                    <TableCell>ราคาขาย</TableCell>
                    <TableCell>จำนวน</TableCell>
                    <TableCell>รายละเอียดสินค้า</TableCell>
                    <TableCell>หมวดหมู่</TableCell>
                    <TableCell>รูปภาพ</TableCell>
                    <TableCell>แก้ไข</TableCell>
                    <TableCell>ลบ</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {getCurrentPageItems().map((product, index) => (
                    <TableRow key={index}>
                      <TableCell>{index + 1}</TableCell>
                      <TableCell>{product.id}</TableCell>
                      <TableCell>{product.name}</TableCell>
                      <TableCell>{product.costPrice}</TableCell>
                      <TableCell>{product.sellingPrice}</TableCell>
                      <TableCell>{product.quantity}</TableCell>
                      <TableCell>{product.description}</TableCell>
                      <TableCell>{product.category}</TableCell>
                      <TableCell>
                        <img src={product.image} alt={product.name} style={{ width: '50px', height: '50px' }} />
                      </TableCell>
                      <TableCell>
                        <IconButton onClick={() => handleEditProduct(product)}>
                          <EditIcon />
                        </IconButton>
                      </TableCell>
                      <TableCell>
                        <IconButton onClick={() => handleDeleteProduct(product.id)}>
                          <DeleteIcon />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </Paper>

          <Pagination
            count={Math.ceil(filteredProducts.length / itemsPerPage)}
            page={currentPage}
            onChange={(event, value) => setCurrentPage(value)} // อัปเดต currentPage ที่นี่เพื่อให้มีค่าใหม่ก่อนเรียกใช้ handleGetProduct
            sx={{
              display: 'flex',
              justifyContent: 'center',
              marginTop: '20px'
            }}
          />


          <ProductDialog
            open={openProductDialog}
            onClose={handleCloseDialog}
            onSave={handleSaveProduct}
            handleGetProduct={handleGetProduct} // Add this prop
          />

          {selectedProduct && selectedProduct.image && (
            <EditProductDialog
              open={openEditDialog}
              onClose={handleCloseDialog}
              product={selectedProduct}
              onUpdate={handleUpdateProduct}
              selectedImageProp={selectedProduct.image}
              setSelectedImageProp={setSelectedImageProp}
            />
          )}



        </Container>
      </Box>
    </Box>
  );
}

export default AdminProduct;